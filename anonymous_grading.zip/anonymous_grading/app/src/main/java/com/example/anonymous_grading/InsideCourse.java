package com.example.anonymous_grading;

import static com.example.anonymous_grading.R.*;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class InsideCourse extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_inside_course);
    }
}